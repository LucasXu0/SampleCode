#ifndef H_ARC4RANDOM_UNIFORM
#define H_ARC4RANDOM_UNIFORM

uint32_t
arc4random_uniform(uint32_t upper_bound);

uint32_t
arc4random();

#endif


#ifndef H_EXPLICIT_BZERO
#define H_EXPLICIT_BZERO

void explicit_bzero(void *buf, size_t len);

#endif